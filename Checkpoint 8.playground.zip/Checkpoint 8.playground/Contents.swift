import Cocoa

protocol Building {
    //Props
    var rooms : Int {get }
    var cost : Int {get}
    var nameOfAgent : String {get}
    
    //method
    func saleSummary ()
}


struct House: Building {
    var rooms: Int
    var cost: Int
    let nameOfAgent: String
    
    func saleSummary (){
        print ("This house has \(rooms) rooms, costs \(cost) euros and the agent responsible is \(nameOfAgent)")
    }
    
}


struct Office : Building {
    var rooms: Int
    var cost: Int
    let nameOfAgent: String
    func saleSummary() {
        print ("This office has \(rooms) rooms, costs \(cost) euros and the agent responsible is \(nameOfAgent)")
    }
}
let house = House(rooms: 5, cost: 500_000, nameOfAgent: "Agbesi Amenyo")
house.saleSummary()

let office = Office(rooms: 30, cost: 1000_000_000, nameOfAgent: "77")
office.saleSummary()


